# GPT baseline — reproduction package

Run (from the folder this zip was extracted into, i.e. the folder containing `src/`):

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export OPENAI_API_KEY=...   # or create a .env file with OPENAI_API_KEY=...

python src/baseline_gpt.py public_data_dev/dev.jsonl
```

This reproduces `runs/run_20260801_205209_full_gpt-5.4.log` (full dev split, 504 instances,
`--context full`, default model `gpt-5.4`), which scored `mean_macro_f1: 0.641`.
Included for reference:

- `runs/run_20260801_205209_full_gpt-5.4.log` — the run log with eval metrics
- `runs/submission_gpt_20260801_205209.jsonl` — the 504 predictions
- `runs/submission_gpt_error_20260801_205209.jsonl` — the 399 misclassified instances

Folder structure is preserved as in the source repo (`src/`, `starting_kit/`, `public_data_dev/`)
since `src/baseline_gpt.py` imports from `starting_kit/` and reads
`public_data_dev/labels_taxonomy.md` via paths relative to its own location.
