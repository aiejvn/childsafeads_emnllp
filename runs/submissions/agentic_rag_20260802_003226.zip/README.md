# agentic_rag baseline -- reproduction package

Run (from the folder this zip was extracted into):

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export OPENAI_API_KEY=...   # or a .env file; agentic_rag also needs OJ_API_KEY

python src/baseline_agentic_rag.py public_data_dev/dev.jsonl
```

`submission.jsonl` in this zip is the predictions being submitted; validate it any time with:

```bash
python starting_kit/check_submission.py submission.jsonl public_data_dev/dev.jsonl
```

Included:
- `src/baseline_gpt.py`
- `src/baseline_agentic_rag.py`
- `oj-eval/src/flowchart.py`
- `oj-eval/src/globals.py`
- `starting_kit/check_submission.py`
- `starting_kit/load_data.py`
- `requirements.txt`
- `public_data_dev/dev.jsonl` -- target split used to produce this submission
- `public_data_dev/labels_taxonomy.md` -- label taxonomy (read by the baseline's system prompt)
- `submission.jsonl` -- the predictions being submitted
- `run_20260801_210444_agentic_rag_full_gpt-5.4.log` -- the run log this submission reproduces

Folder structure is preserved as in the source repo since the scripts import across
`src/`, `starting_kit/`, and (for agentic_rag) `oj-eval/src/` via paths relative to
their own location.
