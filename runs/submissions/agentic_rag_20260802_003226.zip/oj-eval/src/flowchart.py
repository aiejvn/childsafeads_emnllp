from dotenv import load_dotenv
from globals import REQUESTS_MAPPING, OUTPUT_FORMAT_MAPPING, PROVIDER_MAPPING, MODEL_ID_ALIASES, USECASE_DF_IDS, get_provider
from io import BytesIO
import json
import logging
from langchain.chat_models import init_chat_model
# from langchain_community.llms import OpenAI # For OpenAI's non-chat models
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
import os
import re, requests
import time
from typing import List, Callable, Any, Tuple, Dict, TypedDict

logger = logging.getLogger(__name__)


class QueryGenResult(TypedDict):
    query: str

class SufficiencyResult(TypedDict):
    done: bool
    next_query: str


load_dotenv()
llm = None


def init(model_name, t=1):
    global llm
    provider = get_provider(model_name)
    logger.debug(f"{model_name};{os.getenv('AWS_REGION', 'us-east-1')}")
    if provider == 'bedrock':
        from langchain_aws import ChatBedrockConverse
        llm = ChatBedrockConverse(
            model=MODEL_ID_ALIASES.get(model_name, model_name),
            region_name=os.getenv('AWS_REGION', 'us-east-1'),
            temperature=t,
        )
    else:
        llm = init_chat_model(
            MODEL_ID_ALIASES.get(model_name, model_name),
            model_provider=provider,
            temperature=t,
        )



class FlowchartTask:
    def __init__(self, inp):
        self.type = inp['type']
        self.name = inp['name']
        if self.type == 'api':
            if 'url' not in inp or 'endpoint' not in inp:
                pass
            else:
                self.url = inp['url']
                self.endpoint = inp['endpoint']
                self.metadata = inp.get('metadata', {}) # one of these options: concat, topk, random
                self.api_key = os.getenv(inp['api_key']) if 'api_key' in inp else None
        elif self.type == 'llm':
            self.instructions = inp['instructions']
            self.inputFormat = inp.get('input_format', None)
            self.outputFormat = inp.get('output_format', None)
            self.outputFields = inp.get('output_fields', ['answer', 'analysis'])
        elif self.type == 'dialog_flow':
            self.base_url = inp['base_url']
            self.api_key = os.getenv(inp['api_key'])
            usecase = inp.get('usecase')
            if usecase is not None:
                if usecase not in USECASE_DF_IDS:
                    raise ValueError(f"Unknown usecase {usecase!r}; expected one of {sorted(USECASE_DF_IDS)}")
                df_id = USECASE_DF_IDS[usecase]
                if df_id is None:
                    raise ValueError(f"Usecase {usecase!r} has no df_id mapped in globals.USECASE_DF_IDS")
                self.df_id = df_id
                self.usecase = usecase
            else:
                # df_id is now optional at load time: the dataset's per-record `usecase`
                # field can supply it at execution time via _resolve_df_id().
                self.df_id = inp.get('df_id')
                self.usecase = None
            self.stream = inp.get('stream', False)
            self.inline_docs = inp.get('inline_docs', False)
            self.execution_id = None
            self.conversation_id = None
        elif self.type == 'agentic_retrieval':
            self.max_iterations = inp.get('max_iterations', 5)
            retrieval = inp['retrieval']
            self.url = retrieval['url']
            self.endpoint = retrieval['endpoint']
            self.api_key = os.getenv(retrieval['api_key']) if 'api_key' in retrieval else None
            self.metadata = retrieval.get('metadata', {})
            self.query_gen_instructions = inp['query_gen_instructions']
            self.sufficiency_instructions = inp['sufficiency_instructions']
        elif self.type == 'harvey_labs':
            self.max_turns = inp.get('max_turns', 50)
            self.model_override = inp.get('model', None)
            self.system_prompt_extra = inp.get('system_prompt_extra', '')


    def __repr__(self):
        return f"FlowchartNode(name={self.name.__repr__()}, instructions={self.instructions.__repr__()}, inputFormat={self.inputFormat.__repr__()}, outputFormat={self.outputFormat.__repr__()})"

    def to_prompt(self, input, input_reg = '[input]', doc_reg='[docs]'):
        """
        Convert a FlowchartTask to a prompt string.
        """
        assert self.type == 'llm', 'node type mismatch, must be an llm call'

        inp_form = f'Input Format: {self.inputFormat}'
        out_form = f'Output Format: {self.outputFormat}'    

        keys = re.findall(r'(\[(.*?)\])', self.instructions)
        # print(keys)
        instructions = self.instructions
        for k in keys:
            # print(k[0], input[k[1]].value)
            # print('**************************************************************************\n\n\n\n')
            instructions = instructions.replace(k[0], input[k[1]].value)

        return f"""{instructions}
    {(inp_form if self.inputFormat is not None else '')}
    {(out_form if self.outputFormat is not None else '')}
    """

class FlowchartTaskResult:
    def __init__(self, value: Any, executionDetails: Dict):
        self.value = value
        self.executionDetails = executionDetails

    def __dict__(self):
        if 'promptMessages' in self.executionDetails:
            execution_details = {
                **self.executionDetails,
                'promptMessages': [x.content for x in self.executionDetails['promptMessages']]
            }
        else:
            execution_details = self.executionDetails

        return {'value': self.value, 'executionDetails': execution_details}
    
    def __repr__(self):
        return f"FlowchartNodeOutput(value={self.value.__repr__()}, executionDetails={self.executionDetails.__repr__()})"
    
    
class DebugMessage: # LLM func. debug class - use when testing functionality of new benchmarking features
    def __init__(self, content):
        self.content = content
        
    def __dict__(self):
        return {'content':self.content}



def _invoke_llm_structured(instructions: str, local_input: dict, schema) -> dict:
    """Substitute [placeholders], call the LLM with structured output, return the result dict."""
    if 'supporting_docs' in local_input:
        docs = local_input['supporting_docs'].value
        local_input['docs'] = FlowchartTaskResult(
            value='\n\n'.join('{0}: {1}'.format(x['name'], x['content']) for x in docs),
            executionDetails={}
        )
    keys = re.findall(r'(\[(.*?)\])', instructions)
    filled = instructions
    for k in keys:
        if k[1] in local_input:
            filled = filled.replace(k[0], local_input[k[1]].value)
    messages = [HumanMessage(content=filled)]
    try:
        return llm.with_structured_output(schema).invoke(messages)
    except Exception as e:
        logger.warning(f"_invoke_llm_structured failed: {e}")
        return {}


# This is a linear flowchart structure, the nodes are connected in a sequence.
class Flowchart:
    # nodes: List[FlowchartTask]

    def __init__(self, nodes: List[FlowchartTask]):
        self.nodes = nodes


    @staticmethod
    def _docs_text(docs: list) -> str:
        """Unified formatter for supporting docs → plain text."""
        return '\n\n'.join('{0}: {1}'.format(x['name'], x['content']) for x in docs)

    @staticmethod
    def _resolve_df_id(node: 'FlowchartTask', input: dict) -> str:
        """Pick which dialog-flow id to hit for this call.

        Dataset-side `usecase` (propagated in via `execute()`/`retry_errored_df`/
        `rerun_outcome_for_df`) wins over whatever the flowchart JSON pinned at
        load time. This lets one flowchart file run against every usecase
        dataset without editing the JSON between runs.
        """
        ds_uc = input.get('usecase')
        if ds_uc is not None:
            uc_val = ds_uc.value if hasattr(ds_uc, 'value') else ds_uc
            if uc_val and uc_val in USECASE_DF_IDS and USECASE_DF_IDS[uc_val] is not None:
                return USECASE_DF_IDS[uc_val]
        if node.df_id is None:
            raise ValueError(
                f"dialog_flow node {node.name!r} has no df_id and the dataset did not "
                f"supply a usecase that resolves to one (got {ds_uc!r})"
            )
        return node.df_id

    def llm_execution(self, node: FlowchartTask, input) -> FlowchartTaskResult:
        """
        Execute a FlowchartNode and return the output.
        This function simulates the execution of a flowchart node using a basic LLM call.

        currently, the audit is just the prompt and the response from the LLM.
        """
        assert isinstance(
                node, FlowchartTask), "node must be a FlowchartTask instance"
        
        if 'supporting_docs' in input:
            input['docs'] = FlowchartTaskResult(
                value=self._docs_text(input['supporting_docs'].value), executionDetails={}
            )
        messages = [
            HumanMessage(content=node.to_prompt(input)),
        ]
        count = 0
        temp = None
        while count < 3:
            try:
                # Comment out llm line and uncomment Debug one if testing new feaures (to avoid unnecessary LLM calls)
                response = llm.invoke(messages)
                # response = DebugMessage('{"answer": "response", "analysis": "something"}').__dict__()  

                # print(response.content, re.sub(r'\`\`\`.*', '', response.content))
                temp = json.loads(re.sub(r',(?=\n})', '', re.sub(r'\`\`\`.*', '', response.content)).strip().replace('\n', ''))

                break
            except json.decoder.JSONDecodeError as e:
                print('retrying')
                count += 1

        try:
            parts = [str(temp[f]) for f in node.outputFields if f in temp]
            value_str = '\n'.join(parts)
            print("===== LLM Node: ======")
            print(value_str)
            print("======================")
            return FlowchartTaskResult(
                value=value_str,
                executionDetails={"response": response.response_metadata}
            )
        except:
            print( "llm_execution did not get a good response within 3 attempts.")
            return FlowchartTaskResult(
                value="ERROR", 
                executionDetails={"reason": "llm_execution did not get a good response within 3 attempts", "temp":temp}
            )

    def api_execution(self, node: FlowchartTask, input, headers={}) -> FlowchartTaskResult:
        if node.api_key:
            headers = {**headers, 'Authorization': f'Bearer {node.api_key}'}
        if node.url in REQUESTS_MAPPING:
            # print(input)
            text, res, eval = REQUESTS_MAPPING[node.url](node, input, headers)
        else:
            return "Not supported"
        

        out = OUTPUT_FORMAT_MAPPING[node.url](text)
        
        return FlowchartTaskResult(
            value='\n**********\n'.join(out), 
            executionDetails={'full_response': res, 'eval': eval}
        )
        
    ### DF Execution Helper Function: Prettily print a node result.
    def print_node_result(self, node_result: Dict[str, Any], model):
        node_config = node_result.get('nodeConfig', {})
        node_type = node_config.get('type', 'unknown')
        title = node_config.get('label', 'Untitled')
        output = node_result.get('output', '')

        logger.info(f"{model}: {title} ({node_type})")
        if output:
            logger.debug(f"Output: {str(output)}")
                
                
    ### DF Execution helper function for whenever we need to send messages to the convseration
    def send_user_message(self, node: FlowchartTask, conversation_id, input, model="gpt-5-nano", metadata=None):
        url = f"{node.base_url}/messages/{conversation_id}"
        headers = {
            'Authorization': f'Bearer {node.api_key}',
            'Content-Type': 'application/json'
        }
        payload = {
            'model': model,
            'role': 'user',
            'content': input,
            'metadata': metadata or {}
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            logger.info("User message sent successfully")
            return True
        except requests.exceptions.HTTPError as e:
            logger.error(f"Failed to send user message: {e}")
            if e.response is not None:
                logger.error(f"Response: {e.response.text}")
            return False
        except Exception as e:
            logger.error(f"Error sending user message: {e}")
            return False
        
        
    ### DF execution helper function to create a new OJ conversation and return the conversation ID.
    def create_conversation(self, node: FlowchartTask):
        headers = {
            'Authorization': f'Bearer {node.api_key}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        try:
            response = requests.post(
                f'{node.base_url}/conversations',
                headers=headers,
                timeout=30
            )
            response.raise_for_status()
            result = response.json()
            if 'conversationId' not in result:
                raise ValueError("Response missing 'conversationId' field")
            
            return {
                'status': 'success',
                'data': result,
                'conversationId': result['conversationId']
            } 
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
            
    ### DF execution helper: upload supporting text to cloud.
    ### Returns True, {result JSON} if successful, False, {} otherwise.
    ### input should be structured as `{name: ..., content: ...}`
    def upload_str_to_oj(self, node:FlowchartTask, input_doc:Dict):
        file_name, file_content = input_doc['name'], input_doc['content']
        if not file_name.endswith('.txt'):
            file_name = f'{file_name}.txt'  # markdown by default
        file_obj = BytesIO(file_content.encode('utf-8'))

        try:
            response = requests.post(
                f"{node.base_url}/file-library/citations/uploaded",
                headers = {'Authorization': f'Bearer {node.api_key}'},
                files = {'file': (file_name, file_obj, 'text/plain')}
            )
            response.raise_for_status()
            # CitationResponse: {id, name, mimeType, ...}
            return True, response.json()

        except Exception as e:
            logger.error(f"Upload failed for {file_name}: {e}")
            return False, {}
        
    ### DF execution helper: upload all supporting texts to cloud. 
    ### Returns True, {result JSON} if successful, False, {} otherwise.
    def upload_supporting_docs_to_oj(self, node:FlowchartTask, input, stop_on_error=False): 
        supporting_docs = input['supporting_docs'].value
        # Assert supporting docs is a list of {name: ..., content: ...} dicts
        assert isinstance(supporting_docs, list) and all(
            isinstance(x, dict) and "name" in x and "content" in x for x in supporting_docs
        )
        all_results = []
        for doc in supporting_docs:
            _, res = self.upload_str_to_oj(node, doc)
            if stop_on_error and not res: 
                return False, all_results
            all_results.append(res)
        return True, all_results
    
    
    ### When done df execution, delete files from cloud to save space.
    def delete_docs_from_oj(self, node, docs, verify_deleted=False):
        base_url = f"{node.base_url}/file-library/citations"
        all_responses = []
        for doc in docs:
            # doc = CitationResponse: {id, name, ...}
            doc_id = doc.get('id', '')
            try:
                response = requests.delete(
                    f'{base_url}/{doc_id}',
                    headers = {'Authorization': f'Bearer {node.api_key}'}
                )
                response.raise_for_status()  # 204 No Content on success
                all_responses.append({'id': doc_id, 'deleted': True})
            except Exception as e:
                logger.error(f"Deletion failed for {doc_id}: {e}")
            finally:
                if verify_deleted:
                    fetch_file_response = requests.get(
                        f'{base_url}/{doc_id}',
                        headers = {'Authorization': f'Bearer {node.api_key}'}
                    )
                    logger.debug(f"Deletion status for {base_url}/{doc_id}: {fetch_file_response.status_code}")
        return all_responses
    
    
    def _validate_extra_facts(self, extra_facts: dict) -> tuple[bool, str]:
        """Validate extra_facts conforms to the FieldValue schema before any AI calls."""
        required_keys = {'value', 'evidence', 'source', 'confidence'}
        for field_name, fact in extra_facts.items():
            if not isinstance(fact, dict):
                return False, f"extra_facts['{field_name}'] must be a dict, got {type(fact).__name__}"
            missing = required_keys - fact.keys()
            if missing:
                return False, f"extra_facts['{field_name}'] missing keys: {missing}"
            if not isinstance(fact.get('evidence'), list):
                return False, f"extra_facts['{field_name}']['evidence'] must be a list"
            if not isinstance(fact.get('confidence'), (int, float)):
                return False, f"extra_facts['{field_name}']['confidence'] must be numeric"
        return True, ''

    ### Build a predetermined response text based on a given msg.
    ### If there are no matches, we collect all our answers together and give it that.
    def _build_predetermined_response_text(self, all_questions, extra_facts):
        match_keys = {
            'reside in Ontario': ['residency'],
            'subject to a collective agreement': ['worker_status', 'federally_regulated_employment'],
            'workplace changes': ['legal_questions'],
            'expressed terms of the employment contract': ['expressed_contractual_employment_terms'],
            'ancillary terms of employment': ['ancillary_employment_terms'],
            'verbal representations': ['oral_agreements'],
            'believe they were constructively dismissed': ['constructive_dismissal_belief'],
            'employment contractual documents': ['employment_contractual_documents'],
            'evidence of employer changes': ['evidence_of_employer_changes'],
            'workplace conduct evidence': ['workplace_conduct_evidence'],
            'health and medical records': ['health_and_medical_records'],
            'financial and compensation records': ['financial_and_compensation_records'],
            'post-resignation records': ['post_resignation_records'],
            'other documents': ['other_documents'],
            'Ontario law': ['jurisdiction'],
            'resign because of': ['causation'],
            'dependent contractor': ['worker_classification'],
            'in a union': ['unionized'],
            'without asking': ['without_asking'],
            'object or make clear': ['clear_not_accept'],
            'continue working after the change': ['continue_working'],
            'the change was the reason': ['resigned_reason'],
        }
        response_text = ""
        for q in all_questions:
            matched = False
            for key in match_keys:
                if not matched and key.lower() in q.lower():
                    matched = True
                    preloaded_list = match_keys[key]
                    response_text += f"{q} "
                    for preloaded in preloaded_list:
                        val = (extra_facts.get(preloaded) or {}).get('value') or 'null'
                        response_text += f"{val if val.lower() != 'null' else 'No information.'} "
                        logger.info(f"EXTRA FACTS RESPONSE: val:{val}, question:{q}, extra_facts.get(preloaded):{extra_facts.get(preloaded)}")
                    response_text += "\n"
            if not matched:
                logger.warning("No match found in _build_predetermined_response_text")
                response_text += f"{all_questions}\n{str(extra_facts)}"
        return response_text

    ### Send a predetermined response to the DF based on a given msg (conversation-based flow).
    def send_predetermined_response(self, node, all_questions, extra_facts, conversation_id, model, df_id=None):
        response_text = self._build_predetermined_response_text(all_questions, extra_facts)
        logger.debug(f"Response: {response_text}")
        logger.debug("Sending response and resuming execution...")
        return self.send_user_message(node, conversation_id, response_text, model, metadata={
            'dialogFlowId': df_id if df_id is not None else node.df_id
        })
        
    ### Poll the execution status endpoint until the execution reaches a terminal state.
    def poll_execution_status(self, node: FlowchartTask, execution_id: str, poll_interval=3, max_polls=200):
        url = f"{node.base_url}/dialog-flow-executions/{execution_id}/status"
        headers = {'Authorization': f'Bearer {node.api_key}'}
        terminal = {'completed', 'failed', 'cancelled', 'aborted', 'COMPLETED', 'FAILED', 'CANCELLED', 'ABORTED'}
        for i in range(max_polls):
            try:
                resp = requests.get(url, headers=headers, timeout=30)
                resp.raise_for_status()
                status = resp.json().get('status', '')
                logger.debug(f"Polling status ({i+1}): {status}")
                if status in terminal:
                    return status
            except Exception as e:
                logger.warning(f"Status poll error: {e}")
            time.sleep(poll_interval)
        logger.warning("Max polls reached; status unknown")
        return None


    # ### Fetch fact-node field definitions from a dialog flow.
    # ### Returns a list of {"name": ..., "desc": ...} dicts usable by answer_questions().
    # ### Falls back to the legacy /dialog-flows endpoint if the new one fails.
    # ### Keeping around in case needed elsewhere.
    # def fetch_fact_node_fields(self, node: FlowchartTask) -> List[Dict]:
    #     headers = {
    #         'Authorization': f'Bearer {node.api_key}',
    #         'Accept': 'application/json'
    #     }
    #     flow = None
    #     for url in [
    #         f"{node.base_url}/_dialog-flows/{node.df_id}",
    #         f"{node.base_url}/dialog-flows/{node.df_id}",
    #     ]:
    #         try:
    #             resp = requests.get(url, headers=headers, timeout=30)
    #             resp.raise_for_status()
    #             flow = resp.json()
    #             break
    #         except Exception as e:
    #             print(f"   ⚠️ fetch_fact_node_fields: {url} failed: {e}")
    #     if flow is None:
    #         print("   ❌ fetch_fact_node_fields: all endpoints failed")
    #         return []

    #     fields = []
    #     nodes = flow.get('nodes', flow.get('data', {}).get('nodes', []))
    #     for n in nodes:
    #         cfg = n.get('config', n.get('data', {}))
    #         for fd in cfg.get('factDefinitions', []):
    #             label = fd.get('label', '').strip()
    #             instructions = fd.get('instructions', '').strip()
    #             if not label or not instructions:
    #                 continue
    #             enum_vals = [v for v in fd.get('customEnumValues', []) if v != 'null']
    #             desc = instructions
    #             if enum_vals:
    #                 desc += f" ({' / '.join(enum_vals)})"
    #             fields.append({"name": label, "desc": desc})

    #     print(f"   ✅ Fetched {len(fields)} fact-node field(s) from dialog flow {node.df_id}")
    #     return fields


    ### Execute a dialog flow, given we know the df id, and api key.
    ### Different from `api_execution()` because output is streamed.
    # To test, run:
    # python benchmarking.py -m gpt-5-nano -i data/cd_filled_v4_DEBUG.jsonl -f flowcharts/public_oj_api_test.json -o 'data/results' -k 10 -n 1 --overwrite
    # Full benchmarking run on public OJ API: 
    # python benchmarking.py -i data/cd_filled_v3.jsonl -f flowcharts/public_oj_llm_compare.json -o 'data/results' -k 10 --overwrite
    def df_execution(self, node: FlowchartTask, input, model, cur_depth=0, max_depth=10, messages=None, prior_node_results=None, max_retries=3):
        assert isinstance(node, FlowchartTask), "node must be a FlowchartTask instance"

        logger.debug(f"streaming? {node.stream}")

        if node.stream:
            return self._df_execution_streaming(node, input, model, cur_depth, max_depth, max_retries=max_retries)

        execution_data = {
            'full_text': '',
            'node_results': [],
            'facts': {},
            'execution_id': None,
            'status': 'running',
            'error': None
        }

        if cur_depth >= max_depth:
            execution_data['status'] = 'mid-benchmark fatal error'
            execution_data['error'] = 'limit reached'
            logger.warning('Max "await user responses" reached; prematurely ending test.')
            return FlowchartTaskResult(value='', executionDetails=execution_data)

        # ================== Extra facts for answering fact nodes ==================
        extra_facts = None
        if 'extra_fact_node_facts' in input and len(input['extra_fact_node_facts'].value) > 0:
            extra_facts = dict(input['extra_fact_node_facts'].value)

        if extra_facts is not None and cur_depth == 0:
            valid, err = self._validate_extra_facts(extra_facts)
            if not valid:
                execution_data['status'] = 'error'
                execution_data['error'] = f'extra_facts schema validation failed: {err}'
                logger.error(f'extra_facts schema validation failed: {err}')
                return FlowchartTaskResult(value='', executionDetails=execution_data)

        # ================== Prepare messages (depth-0 only) ==================
        docs_uploaded = []
        if cur_depth == 0:
            initial_msg = input['input'].value
            if node.inline_docs:
                file_ids = []
                docs_text = self._docs_text(input['supporting_docs'].value)
                initial_msg += "\n\n=========SUPPORTING DOCUMENTS=========\n\n" + docs_text
                logger.info("Inline docs mode: supporting docs appended to initial message")
            else:
                upload_status, docs_uploaded = self.upload_supporting_docs_to_oj(node, input, True)
                if upload_status:
                    logger.info("All supporting documents uploaded")
                else:
                    logger.warning("Some supporting docs could not be uploaded")
                file_ids = [doc["id"] for doc in docs_uploaded]

            logger.debug(f"Initial MSG: {initial_msg}")
            messages = [{'content': initial_msg, 'fileIds': file_ids}]
            logger.info("Prepared initial message for stateless execution")

        # ================== POST to /run (non-streaming) ==================
        url = f"{node.base_url}/dialog-flow-executions/run"
        headers = {
            'Authorization': f'Bearer {node.api_key}',
            'Content-Type': 'application/json',
        }
        df_id = self._resolve_df_id(node, input)
        body = {'dialogFlowId': df_id, 'messages': messages, 'model': model}
        if prior_node_results is not None:
            body['priorState'] = {'nodeResults': prior_node_results}
        logger.debug(f"POST {url}  (depth={cur_depth}, msgs={len(messages)}, df={df_id}, priorState={prior_node_results})")

        try:
            response = requests.post(url, json=body, headers=headers, timeout=86400)
            logger.debug(f"HTTP {response.status_code}")
            logger.debug(f"Raw response: {response.text[:1000]}")
            response.raise_for_status()
            data = response.json()

            # Note: as of 4/14/2026, we are using STATELESS execution.
            # This means execution ID is not queryable or retrievable from memory
            execution_data['execution_id'] = data.get('executionId')
            execution_data['node_results'] = data.get('nodeResults', [])
            execution_data['facts'] = data.get('facts', {})
            status = data.get('status', '')
            status_normalized = status.upper().replace('-', '_')
            logger.debug(f"status={status}  nodeResults={len(execution_data['node_results'])}  facts={list(execution_data['facts'].keys())}")

            if status_normalized == 'COMPLETED':
                execution_data['status'] = 'completed'
                execution_data['full_text'] = data.get('finalOutput', '')
                logger.debug(f"finalOutput: {execution_data['full_text']}")

            elif status_normalized == 'AWAITING_INPUT':
                execution_data['status'] = 'paused'
                missing = data.get('missingFactDefinitions', [])
                all_questions = [f.get('instructions', '') for f in missing]
                logger.info(f"AWAITING_INPUT — {len(missing)} missing fact(s): {'; '.join(all_questions)}")

                if not extra_facts:
                    response_text = "\n".join(f"{q}\nN/A" for q in all_questions) if all_questions else "N/A"
                    logger.warning(f'No extra facts available; responding with N/A for {len(all_questions)} question(s).')
                else:
                    response_text = self._build_predetermined_response_text(all_questions, extra_facts)
                logger.debug(f"Responding with: {response_text}")
                resumed = self.df_execution(
                    node, input, model,
                    cur_depth=cur_depth + 1,
                    max_depth=max_depth,
                    messages=messages + [{'content': response_text}],
                    prior_node_results=execution_data['node_results'],
                    max_retries=max_retries,
                )
                execution_data['full_text'] += resumed.executionDetails['full_text']
                execution_data['node_results'].extend(resumed.executionDetails['node_results'])
                execution_data['facts'].update(resumed.executionDetails['facts'])
                execution_data['status'] = resumed.executionDetails['status']
                execution_data['error'] = resumed.executionDetails['error']

            elif status_normalized == 'FAILED':
                failed_node_id = data.get('failedNodeId')
                node_results_on_failure = data.get('nodeResults', [])
                logger.error(f"DF failed at node {failed_node_id}: {data.get('error') or data.get('message')}")
                logger.debug(f"All data returned:{data}")
                logger.debug(f"nodes executed so far:{node_results_on_failure}")
                assert len(node_results_on_failure) > 0, "Got no node results back."
                if max_retries > 0 and node_results_on_failure:
                    logger.warning(f"Retrying from failed state ({max_retries} retries left)...")
                    retry_result = self.df_execution(
                        node, input, model,
                        cur_depth=cur_depth,
                        max_depth=max_depth,
                        messages=messages,
                        prior_node_results=node_results_on_failure,
                        max_retries=max_retries - 1,
                    )
                    execution_data['full_text'] = retry_result.executionDetails['full_text']
                    execution_data['node_results'] = retry_result.executionDetails['node_results']
                    execution_data['facts'] = retry_result.executionDetails['facts']
                    execution_data['status'] = retry_result.executionDetails['status']
                    execution_data['error'] = retry_result.executionDetails['error']
                else:
                    execution_data['status'] = 'failed'
                    execution_data['error'] = data.get('error') or data.get('message', 'unknown failure')

            elif status_normalized == 'ABORTED':
                execution_data['status'] = 'aborted'
                execution_data['error'] = data.get('error') or data.get('message', 'execution aborted')
                logger.error(f"DF aborted: {execution_data['error']}")

            else:
                execution_data['status'] = status.lower() if status else 'unknown'
                logger.warning(f"Unexpected status: {status}")

        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code and max_retries > 0:
                logger.warning(f"{e.response.status_code} — retrying ({max_retries} retries left). Waiting 5 s...")
                time.sleep(5)
                # Preserve any partial node_results/facts that came back before the 502
                partial_node_results = execution_data.get('node_results') or None
                retry_prior = partial_node_results if partial_node_results else prior_node_results
                logger.debug("Sending back partial node results" if partial_node_results else "No partial node results found")
                if not (partial_node_results or prior_node_results):
                    logger.error("No prior results anywhere. exiting..")
                    execution_data['status'] = 'error'
                    execution_data['error'] = f'HTTPError with no prior node results to retry from: {e}'
                else:
                    retry_result = self.df_execution(
                        node, input, model,
                        cur_depth=cur_depth,
                        max_depth=max_depth,
                        messages=messages,
                        prior_node_results=retry_prior,
                        max_retries=max_retries - 1,
                    )
                    # Propagate retry result through execution_data so the finally return picks it up
                    execution_data = retry_result.executionDetails
            else:
                execution_data['status'] = 'error'
                execution_data['error'] = str(e)
                logger.error(f"HTTP Error: {e}")
        except Exception as e:
            execution_data['status'] = 'error'
            execution_data['error'] = str(e)
            logger.error(f"{type(e).__name__}: {e}")
        finally:
            # if cur_depth == 0:
            #     self.delete_docs_from_oj(node, docs_uploaded, verify_deleted=True)
            logger.debug("Skipping file deletion")
            return FlowchartTaskResult(
                value=execution_data['full_text'],
                executionDetails=execution_data
            )


    def _fetch_last_message(self, node: FlowchartTask, conversation_id: str) -> dict | None:
        """GET /messages/{conversationId} and return the last message dict, or None on failure."""
        headers = {'Authorization': f'Bearer {node.api_key}'}
        try:
            resp = requests.get(
                f"{node.base_url}/messages/{conversation_id}",
                headers=headers, timeout=30
            )
            resp.raise_for_status()
            messages = resp.json()
            if isinstance(messages, list) and messages:
                return messages[-1]
        except Exception as e:
            logger.error(f"Failed to fetch messages for conversation {conversation_id}: {e}")
        return None


    def _stream_conversation(self, node: FlowchartTask, message, conversation_id, model, resources, resume_execution_id=None, df_id=None):
        """POST to /conversations/stream (SSE) and yield (event_type, data) pairs."""
        headers = {
            'Authorization': f'Bearer {node.api_key}',
            'Content-Type': 'application/json',
            'Accept': 'text/event-stream',
        }
        body = {
            'message': message,
            'conversationId': conversation_id,
            'dialogFlowId': df_id if df_id is not None else node.df_id,
            'model': model,
            'resources': resources,
        }
        if resume_execution_id:
            body['resumeExecutionId'] = resume_execution_id

        response = requests.post(
            f"{node.base_url}/conversations/stream",
            json=body, headers=headers, stream=True, timeout=86400
        )
        response.raise_for_status()

        current_event = None
        for line in response.iter_lines(decode_unicode=True):
            if line.startswith('event: '):
                current_event = line[7:].strip()
            elif line.startswith('data: '):
                try:
                    yield current_event, json.loads(line[6:])
                except json.JSONDecodeError:
                    pass
            elif line == '':
                current_event = None


    def _df_execution_streaming(self, node: FlowchartTask, input, model,
                                 cur_depth=0, max_depth=10,
                                 conversation_id=None, execution_id=None,
                                 message_override=None, max_retries=3):
        """Execute a dialog_flow node via the live /conversations/stream SSE endpoint."""
        execution_data = {
            'full_text': '',
            'node_results': [],
            'facts': {},
            'execution_id': execution_id,
            'conversation_id': conversation_id,
            'status': 'running',
            'error': None
        }

        if cur_depth >= max_depth:
            execution_data['status'] = 'mid-benchmark fatal error'
            execution_data['error'] = 'limit reached'
            logger.warning('Max "await user responses" reached; prematurely ending test.')
            return FlowchartTaskResult(value='', executionDetails=execution_data)

        extra_facts = None
        if 'extra_fact_node_facts' in input and len(input['extra_fact_node_facts'].value) > 0:
            extra_facts = dict(input['extra_fact_node_facts'].value)

        if extra_facts is not None and cur_depth == 0:
            valid, err = self._validate_extra_facts(extra_facts)
            if not valid:
                execution_data['status'] = 'error'
                execution_data['error'] = f'extra_facts schema validation failed: {err}'
                logger.error(f'extra_facts schema validation failed: {err}')
                return FlowchartTaskResult(value='', executionDetails=execution_data)

        resources = []
        docs_uploaded = []
        if cur_depth == 0:
            if node.inline_docs:
                docs_text = self._docs_text(input['supporting_docs'].value)
                logger.info("Inline docs mode: supporting docs will be appended to initial message")
            else:
                upload_status, docs_uploaded = self.upload_supporting_docs_to_oj(node, input, True)
                if upload_status:
                    logger.info("All supporting documents uploaded")
                else:
                    logger.warning("Some supporting docs could not be uploaded")
                resources = [
                    {"id": d["id"], "name": d.get("name", ""), "mimeType": d.get("mimeType", "text/plain")}
                    for d in docs_uploaded if d.get("id")
                ]

            conv_result = self.create_conversation(node)
            if conv_result['status'] != 'success':
                execution_data['status'] = 'error'
                execution_data['error'] = f"Failed to create conversation: {conv_result.get('error')}"
                logger.error(f"Failed to create conversation: {conv_result.get('error')}")
                return FlowchartTaskResult(value='', executionDetails=execution_data)
            conversation_id = conv_result['conversationId']
            node.conversation_id = conversation_id
            execution_data['conversation_id'] = conversation_id

            message = input['input'].value
            if node.inline_docs:
                message += "\n\n=========SUPPORTING DOCUMENTS=========\n\n" + docs_text
            logger.info(f"Created conversation {conversation_id}; streaming DF {self._resolve_df_id(node, input)}")
        else:
            message = message_override
            execution_data['conversation_id'] = conversation_id
            logger.debug(f"Resuming stream (depth={cur_depth}, executionId={execution_id})")

        current_execution_id = execution_id
        awaiting_input_data = None
        heartbeat_timeout = False
        _HEARTBEAT_TIMEOUT_S = 600  # 10 minutes

        try:
            df_id = self._resolve_df_id(node, input)
            last_real_event_time = time.time()
            for event_type, data in self._stream_conversation(
                    node, message, conversation_id, model,
                    resources,
                    resume_execution_id=execution_id,
                    df_id=df_id):

                if event_type == 'heartbeat':
                    if time.time() - last_real_event_time > _HEARTBEAT_TIMEOUT_S:
                        heartbeat_timeout = True
                        logger.warning(
                            f"10-minute heartbeat timeout for conversation {conversation_id}; "
                            "falling back to GET /messages"
                        )
                        break
                    continue

                last_real_event_time = time.time()
                logger.debug(f"SSE event={event_type}  data={str(data)}")

                if event_type == 'execution-started':
                    current_execution_id = data.get('executionId')
                    execution_data['execution_id'] = current_execution_id

                elif event_type == 'message':
                    execution_data['full_text'] += data.get('text', '')

                elif event_type == 'node-result':
                    execution_data['node_results'].append(data)

                elif event_type == 'execution-completed':
                    execution_data['status'] = 'completed'
                    final = data.get('finalOutput', '')
                    if final:
                        execution_data['full_text'] = final

                elif event_type == 'awaiting-user-input':
                    awaiting_input_data = data
                    break

                elif event_type == 'done':
                    break

            if heartbeat_timeout:
                last_msg = self._fetch_last_message(node, conversation_id)
                if last_msg and last_msg.get('role') == 'assistant':
                    execution_data['full_text'] = last_msg.get('content', '')
                    execution_data['status'] = 'completed'
                    execution_data['error'] = 'completed via heartbeat-timeout fallback (GET /messages)'
                    logger.info("Heartbeat timeout: recovered last assistant message via GET /messages")
                else:
                    execution_data['status'] = 'error'
                    execution_data['error'] = (
                        'heartbeat timeout: last message was not from assistant'
                        if last_msg else
                        'heartbeat timeout: could not fetch last message'
                    )
                    logger.error(f"Heartbeat timeout fallback failed: last_msg={last_msg}")

            elif awaiting_input_data is not None:
                missing = awaiting_input_data.get('nodeExecutionResults', {}).get('missingFactDefinitions', [])
                all_questions = [f.get('instructions', '') for f in missing]
                logger.info(f"AWAITING_INPUT — {len(missing)} missing fact(s): {'; '.join(all_questions)}")

                if not extra_facts:
                    response_text = "\n".join(f"{q}\nN/A" for q in all_questions) if all_questions else "N/A"
                    logger.warning(f'No extra facts available; responding with N/A for {len(all_questions)} question(s).')
                else:
                    response_text = self._build_predetermined_response_text(all_questions, extra_facts)
                logger.debug(f"Responding with: {response_text}")
                resumed = self._df_execution_streaming(
                    node, input, model,
                    cur_depth=cur_depth + 1,
                    max_depth=max_depth,
                    conversation_id=conversation_id,
                    execution_id=current_execution_id,
                    message_override=response_text,
                    max_retries=max_retries,
                )
                execution_data['full_text'] += resumed.executionDetails['full_text']
                execution_data['node_results'].extend(resumed.executionDetails['node_results'])
                execution_data['facts'].update(resumed.executionDetails['facts'])
                execution_data['status'] = resumed.executionDetails['status']
                execution_data['error'] = resumed.executionDetails['error']

            elif execution_data['status'] == 'running':
                execution_data['status'] = 'completed'

        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code and max_retries > 0:
                logger.warning(f"{e.response.status_code} (streaming) — retrying ({max_retries} retries left). Waiting 5 s...")
                time.sleep(5)
                retry_execution_id = current_execution_id
                resume_resp = requests.post(
                    f"{node.base_url}/dialog-flow-executions/{retry_execution_id}/resume",
                    headers={'Authorization': f'Bearer {node.api_key}', 'Content-Type': 'application/json'},
                )
                logger.info(f"RESUME [{resume_resp.status_code}]: {resume_resp.text}")
                resume_resp.raise_for_status()
                data = resume_resp.json()
                execution_data['execution_id'] = data.get('executionId')
                execution_data['node_results'] = data.get('nodeResults', [])
                execution_data['facts'] = data.get('facts', {})
                status = data.get('status', '')
                status_normalized = status.upper().replace('-', '_')
                if status_normalized == 'COMPLETED':
                    execution_data['status'] = 'completed'
                    execution_data['full_text'] = data.get('finalOutput', '')
                elif status_normalized == 'FAILED':
                    execution_data['status'] = 'failed'
                    execution_data['error'] = data.get('error') or data.get('message', 'unknown failure')
                elif status_normalized == 'ABORTED':
                    execution_data['status'] = 'aborted'
                    execution_data['error'] = data.get('error') or data.get('message', 'execution aborted')
                else:
                    execution_data['status'] = status.lower() if status else 'unknown'
                    logger.warning(f"Unexpected RESUME status: {status}")
                return
            execution_data['status'] = 'error'
            execution_data['error'] = str(e)
            logger.error(f"HTTP Error: {e}")
        except Exception as e:
            execution_data['status'] = 'error'
            execution_data['error'] = str(e)
            logger.error(f"{type(e).__name__}: {e}")
        finally:
            logger.debug("Skipping file deletion")
            return FlowchartTaskResult(
                value=execution_data['full_text'],
                executionDetails=execution_data
            )


    def _invoke_llm_json(self, instructions: str, local_input: dict) -> dict:
        """Substitute [placeholders], call the LLM, return the parsed JSON dict."""
        if 'supporting_docs' in local_input:
            local_input['docs'] = FlowchartTaskResult(
                value=self._docs_text(local_input['supporting_docs'].value), executionDetails={}
            )
        keys = re.findall(r'(\[(.*?)\])', instructions)
        filled = instructions
        for k in keys:
            if k[1] in local_input:
                filled = filled.replace(k[0], local_input[k[1]].value)
        messages = [HumanMessage(content=filled)]
        for _ in range(3):
            try:
                response = llm.invoke(messages)
                return json.loads(re.sub(r',(?=\n})', '', re.sub(r'\`\`\`.*', '', response.content)).strip().replace('\n', ''))
            except json.JSONDecodeError:
                pass
        logger.warning("_invoke_llm_json failed to parse JSON after 3 attempts.")
        return {}


    def agentic_retrieval_execution(self, node: FlowchartTask, input: dict) -> FlowchartTaskResult:
        dedup_key = node.metadata.get('dedup_key', '')
        all_raw = []
        seen_ids = set()
        iter_evals = []
        local_input = dict(input)
        headers = {'Authorization': f'Bearer {node.api_key}'} if node.api_key else {}

        # Generate the initial query
        q = _invoke_llm_structured(node.query_gen_instructions, local_input, QueryGenResult)
        current_query = q.get('query', '')
        logger.info(f"[Agentic] Initial query: {current_query}")

        # Lightweight namespace so REQUESTS_MAPPING handlers get node-like object
        class _RetNode:
            pass

        iterations_run = 0
        for i in range(node.max_iterations):
            iterations_run = i + 1
            logger.info(f"[Agentic] Iteration {iterations_run}/{node.max_iterations}")

            local_input['_AGENTIC_QUERY'] = FlowchartTaskResult(value=current_query, executionDetails={})

            ret = _RetNode()
            ret.url = node.url
            ret.endpoint = node.endpoint
            ret.api_key = node.api_key
            ret.metadata = {
                **node.metadata,
                'query': {**node.metadata.get('query', {}), 'query': '_AGENTIC_QUERY'}
            }

            # [0] items: processed results (filtered by output_strat for DB, search blocks for websearch)
            # [1] raw:   full DB payload or {} for websearch — unused in agentic loop
            # [2] eval:  precision@k dict for DB, {"enabled?": False} for websearch
            items, _, iter_eval = REQUESTS_MAPPING[node.url](ret, local_input, headers)
            iter_evals.append({'iteration': iterations_run, 'query': current_query, 'eval': iter_eval})

            for item in items:
                item_id = item.get(dedup_key) if dedup_key else None
                if item_id:
                    if item_id not in seen_ids:
                        seen_ids.add(item_id)
                        all_raw.append(item)
                else:
                    all_raw.append(item)  # no dedup_key set: accumulate all

            logger.info(f"[Agentic] {len(all_raw)} total item(s) accumulated")

            formatted = OUTPUT_FORMAT_MAPPING[node.url](all_raw)
            local_input['ACCUMULATED_RESULTS'] = FlowchartTaskResult(
                value='\n**********\n'.join(formatted),
                executionDetails={}
            )

            if i < node.max_iterations - 1:
                check = _invoke_llm_structured(node.sufficiency_instructions, local_input, SufficiencyResult)
                done = check.get('done', False)
                logger.info(f"[Agentic] Sufficiency check: done={done}")
                if done:
                    break
                next_q = check.get('next_query', '').strip()
                if next_q:
                    current_query = next_q
                    logger.info(f"[Agentic] Next query: {current_query}")

        final = OUTPUT_FORMAT_MAPPING[node.url](all_raw)
        return FlowchartTaskResult(
            value='\n**********\n'.join(final),
            executionDetails={
                'iterations': iterations_run,  # number of retrieval iterations run
                'total_items': len(all_raw),   # unique items accumulated after dedup
                'iter_evals': iter_evals        # per-iteration: {iteration, query, eval}
            }
        )


    def harvey_labs_execution(self, node: FlowchartTask, input, model) -> FlowchartTaskResult:
        """Execute a harvey_labs node by running the harvey-labs agent loop.

        The agent reads the supporting documents, reasons about the legal
        question, and writes its answer. No Docker/podman required — uses
        a lightweight local sandbox.
        """
        from harvey_harness import run_harvey_agent

        docs = input['supporting_docs'].value  # list of {name, content} dicts
        query = input['input'].value
        agent_model = node.model_override or model

        try:
            result = run_harvey_agent(
                query=query,
                supporting_docs=docs,
                model=agent_model,
                max_turns=node.max_turns,
                system_prompt_extra=node.system_prompt_extra,
            )

            return FlowchartTaskResult(
                value=result['answer'],
                executionDetails={
                    'turn_count': result['turn_count'],
                    'input_tokens': result['input_tokens'],
                    'output_tokens': result['output_tokens'],
                    'wall_clock_seconds': result['wall_clock_seconds'],
                    'finished_cleanly': result['finished_cleanly'],
                    'status': 'completed' if result['finished_cleanly'] else 'error',
                }
            )
        except Exception as e:
            logger.error(f"Harvey-labs agent execution failed: {e}")
            return FlowchartTaskResult(
                value='ERROR',
                executionDetails={'status': 'error', 'reason': str(e)}
            )

    def _node_dependencies(self, node: FlowchartTask) -> set:
        """Return the set of result keys this node reads via [placeholder] syntax."""
        instructions = []
        if node.type == 'llm':
            instructions = [node.instructions]
        elif node.type == 'agentic_retrieval':
            instructions = [node.query_gen_instructions, node.sufficiency_instructions]
        deps = set()
        for instr in instructions:
            for key in re.findall(r'\[([^\]]+)\]', instr):
                deps.add(key)
        return deps

    def _is_failed(self, result: FlowchartTaskResult) -> bool:
        if result.value in ('ERROR', 'SKIPPED'):
            return True
        status = result.executionDetails.get('status', '') if isinstance(result.executionDetails, dict) else ''
        return any(s in status for s in ('error', 'fail', 'abort'))

    def _resolve_nodes_to_run(self, only_approaches=None, node_to_approach=None):
        """Determine which nodes to execute based on requested approaches.

        Returns a set of node names to run. Includes dependency nodes that
        target nodes reference via [placeholder] syntax, even if those
        dependency nodes belong to a different approach.

        If only_approaches is None, all nodes run (existing behavior).
        """
        if not only_approaches or not node_to_approach:
            return None  # run everything

        # Start with nodes whose approach is requested
        target_names = set()
        for node in self.nodes:
            approach = node_to_approach.get(node.name)
            if approach and approach in only_approaches:
                target_names.add(node.name)

        # Expand with dependency nodes (transitive)
        all_node_names = {node.name for node in self.nodes}
        expanded = set(target_names)
        changed = True
        while changed:
            changed = False
            for node in self.nodes:
                if node.name not in expanded:
                    continue
                for dep in self._node_dependencies(node):
                    if dep in all_node_names and dep not in expanded:
                        expanded.add(dep)
                        changed = True

        return expanded

    def execute(self, input: Any, model:str, tqdm_print=False,
                only_approaches=None, node_to_approach=None) -> List[FlowchartTaskResult]:
        assert isinstance(self.nodes, list), "flowchart must be a list of FlowchartTask instances"

        nodes_to_run = self._resolve_nodes_to_run(only_approaches, node_to_approach)

        res = []
        for variation, docs in input['supporting_docs'].items():
            logger.info(f"Running variation: {variation}")
            results = {
                'supporting_docs': FlowchartTaskResult(value=docs[1], executionDetails={}),
                'input': FlowchartTaskResult(value=input['query'], executionDetails={}),
            }

            if 'usecase' in input and input['usecase']:
                results['usecase'] = FlowchartTaskResult(value=input['usecase'], executionDetails={})

            if 'extra_fact_node_facts' in input:
                results['extra_fact_node_facts'] = FlowchartTaskResult(value=input['extra_fact_node_facts'], executionDetails={})
                logger.info('Input has extra facts.')
            else:
                logger.warning('No extra facts detected to reply with.')

            failed_nodes = set()

            for node in self.nodes:
                # Skip nodes not in the target set
                if nodes_to_run is not None and node.name not in nodes_to_run:
                    logger.info(f"Skipping node '{node.name}': not in requested approaches")
                    continue

                deps = self._node_dependencies(node)
                blocking = deps & failed_nodes
                if blocking:
                    logger.warning(f"Skipping node '{node.name}': depends on failed node(s) {blocking}")
                    failed_nodes.add(node.name)
                    continue

                try:
                    if node.type == 'llm':
                        result = self.llm_execution(node, results)
                    elif node.type == 'api':
                        result = self.api_execution(node, results)
                    elif node.type == 'dialog_flow':
                        result = self.df_execution(node, results, model)
                    elif node.type == 'agentic_retrieval':
                        result = self.agentic_retrieval_execution(node, results)
                    elif node.type == 'harvey_labs':
                        result = self.harvey_labs_execution(node, results, model)
                    else:
                        result = FlowchartTaskResult(value='SKIPPED', executionDetails={'status': 'skipped', 'reason': 'unknown node type'})
                except Exception as e:
                    logger.error(f"Node '{node.name}' raised an unhandled exception: {e}")
                    result = FlowchartTaskResult(value='ERROR', executionDetails={'status': 'error', 'reason': str(e)})

                results[node.name] = result
                if self._is_failed(result):
                    logger.warning(f"Node '{node.name}' failed — downstream dependents will be skipped")
                    failed_nodes.add(node.name)

            res.append(list(results.items()))
        return res


def load_flowchart(filename: str):
    with open(filename, 'r') as f:
        data = json.load(f)

    return Flowchart([FlowchartTask(x) for x in data])