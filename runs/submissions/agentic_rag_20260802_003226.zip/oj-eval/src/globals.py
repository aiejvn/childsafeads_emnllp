import requests, random, re, time, logging, tempfile, os
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO

logger = logging.getLogger(__name__)

def google_form(results):
    return [f"Title: {x['title']}\n\nSnippet: {x['snippet']}" for x in results]


def web_search(node, input, headers):
    logger.info("Executing web search...")
    query_config = node.metadata.get('query', {})
    query_key = query_config.get('query')
    query_text = input[query_key].value if query_key and query_key in input else None
    if not query_text:
        logger.warning("No query text found for web search.")
        return [], {}, {"enabled?": False}

    model_name = query_config.get('model', 'gpt-5.4-mini')
    try:
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        search_model = ChatOpenAI(
            model=model_name,
            api_key=node.api_key,
            output_version="responses/v1",
            timeout=120,
            max_retries=2,
        ).bind_tools([{"type": "web_search_preview"}])
        response = search_model.invoke([HumanMessage(content=query_text)])

        content = response.content if isinstance(response.content, list) else [{'type': 'text', 'text': str(response.content), 'annotations': []}]
        results = []
        for block in content:
            if isinstance(block, dict) and block.get('type') == 'text':
                annotations = [
                    {'url': a.get('url', ''), 'title': a.get('title', '')}
                    for a in block.get('annotations', [])
                    if a.get('type') == 'url_citation' and a.get('url')
                ]
                results.append({'text': block.get('text', ''), 'annotations': annotations})

        logger.info(f"Web search returned {len(results)} block(s).")
        return results, {}, {"enabled?": False}
    except Exception as e:
        logger.error(f"Web search failed: {e}")
        return [], {}, {"enabled?": False}


def websearch_form(results):
    out = []
    for r in results:
        text = r.get('text', '')
        sources = '\n'.join(
            f"- {a.get('title', 'Source')}: {a['url']}"
            for a in r.get('annotations', [])
            if a.get('url')
        )
        out.append(f"{text}\n\nSources:\n{sources}" if sources else text)
    return out


def vectordb_form(results):
    out = []
    for x in results:
        doc = re.sub(r'[\s]{2,}', ' ', x['chunkText'])
        out.append(f"Relevance: {x['score']}\nDocument: {doc}")
    return out


def db_retrieval(node, input, headers):
    logger.info("Executing vector retrieval...")
    if 'query' in node.metadata:
        query_config = node.metadata['query']
        query_key = query_config.get('query')
        query_text = input[query_key].value if query_key and query_key in input else None
        if not query_text:
            print("No query text found.")
            return []
        data = {'query': query_text, 'scope': query_config.get('scope', 'all')}
        if query_config.get('limit') is not None:
            data['limit'] = query_config['limit']
        if query_config.get('filter') is not None:
            data['filter'] = query_config['filter']
        protocol = 'https://' if not node.url.startswith('localhost') else 'http://'
        response = requests.post(url=''.join([protocol, node.url, '/files/search']), json=data, headers=headers)

        logger.info("===== OJ RAG: ======")
        logger.info(str(response.status_code) + response.text)
        logger.info("======================")

        if not response.text.strip():
            logger.warning("[warning] Empty response body from vector DB.")
            return [], [], { "enabled?": False }

        res = response.json()
        logger.info("Received response is a valid JSON")

        # Inject content into chunkText for each result
        if res and node.api_key:
            full_file = query_config.get('full_file', False)
            if full_file:
                logger.debug(f"full_file=True: downloading full text for {len(res)} result(s)...")
                file_texts = fetch_file_texts(
                    [r['fileId'] for r in res],
                    node.url,
                    node.api_key,
                    max_retries=2)
            else:
                logger.debug(f"full_file=False: fetching metadata for {len(res)} result(s)...")
                file_texts = fetch_file_metadata(
                    [r['fileId'] for r in res],
                    node.url,
                    node.api_key,
                    max_retries=2)
            logger.debug(str(file_texts))
            for r in res:
                fetched = file_texts.get(r['fileId'])
                r['chunkText'] = fetched if fetched else r.get('chunkText', '')
            logger.debug("File content fetched.")

        text = []
        output_strat = node.metadata['output_strat']
        if output_strat == 'concat':
            text = res
        elif output_strat.startswith('top'): # top k, where k is < 10
            text.extend(res[:int(output_strat[-1])]) 
        elif output_strat == 'random': # random k, where k is < 10
            text.append(random.sample(res, k=int(output_strat[-1])))
            
        eval = { "enabled?": False }
        if "metrics" in node.metadata and len(node.metadata["metrics"]) > 0:
            k = int(output_strat[-1])
            original_docs = [doc["name"].rsplit('.', 1)[0] for doc in input['supporting_docs'].value]
            topk_docs = [vec["fileId"] for vec in res]

            eval["enabled?"] = True
            eval["predicted"] = topk_docs
            eval["actual"] = original_docs

            for metric in node.metadata["metrics"]:
                if metric == "precision":
                    # Vector docs in DB don't have file endings, so we drop file endings from supporting docs here
                    eval[f"precision@{k}"] = top_k_precision(topk_docs, original_docs, k)
                    
        logger.debug("Vector retrieval successful.")
        return text, res, eval
    else:
        return []

            
def _detect_ext(resp, content: bytes) -> str:
    # 1. Filename from Content-Disposition
    disposition = resp.headers.get('Content-Disposition', '')
    if 'filename=' in disposition:
        filename = disposition.split('filename=')[-1].strip('"\'').split(';')[0].strip()
        ext = os.path.splitext(filename)[1].lower()
        if ext in ['.pdf', '.docx', '.doc', '.png', '.jpg']:
            return ext
    # 2. Content-Type MIME mapping
    mime = resp.headers.get('Content-Type', '').split(';')[0].strip()
    mime_ext = {
        'application/pdf': '.pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
        'application/msword': '.doc',
        'image/png': '.png',
        'image/jpeg': '.jpg',
        'text/plain': '.txt',
    }.get(mime)
    if mime_ext:
        return mime_ext
    # 3. Magic bytes — handles octet-stream and other opaque content types
    if content[:4] == b'%PDF':
        return '.pdf'
    if content[:4] == b'PK\x03\x04':
        return '.docx'
    if content[:4] == b'\x89PNG':
        return '.png'
    if content[:3] == b'\xff\xd8\xff':
        return '.jpg'
    if content[:8] == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1':
        return '.doc'
    return '.txt'


def _extract_text_from_bytes(content: bytes, ext: str) -> str:
    logger.debug("extension:" + ext)
    if ext == '.pdf':
        import PyPDF2
        reader = PyPDF2.PdfReader(BytesIO(content))
        return '\n'.join(page.extract_text() or '' for page in reader.pages)
    elif ext in ('.docx', '.doc'):
        from langchain_community.document_loaders import UnstructuredWordDocumentLoader
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
            f.write(content)
            tmp = f.name
        try:
            data = UnstructuredWordDocumentLoader(tmp).load()
            return data[0].page_content if data else ''
        finally:
            os.unlink(tmp)
    elif ext in ('.png', '.jpg', '.jpeg'):
        from langchain_community.document_loaders.image import UnstructuredImageLoader
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
            f.write(content)
            tmp = f.name
        try:
            data = UnstructuredImageLoader(tmp).load()
            return data[0].page_content if data else ''
        finally:
            os.unlink(tmp)
    else:
        return content.decode('utf-8', errors='ignore')


def fetch_file_metadata(
    file_ids: list,
    base_url: str,
    api_key: str,
    max_workers: int = 3,
    max_retries: int = 2,
    base_backoff: float = 1.0,
) -> dict:
    """
    Fetch metadata for multiple fileIds in parallel via GET /file-library/citations/:id.
    Returns dict mapping fileId -> text: enrichment summary if present, else preview.
    """
    protocol = 'https://' if not base_url.startswith('localhost') else 'http://'

    def fetch_one(file_id):
        url = f"{protocol}{base_url}/file-library/citations/{file_id}"
        headers = {"Authorization": f"Bearer {api_key}"}
        last_exc = None
        for attempt in range(max_retries):
            try:
                resp = requests.get(url, headers=headers, timeout=15)
                resp.raise_for_status()
                data = resp.json()
                summary = None
                for enrichment in (data.get('metadata') or {}).get('enrichments', []):
                    s = (enrichment.get('contents') or {}).get('summary')
                    if s:
                        summary = s
                        break
                if not summary: logger.warning("Summary not found, using previews")
                return file_id, summary or data.get('preview', '')
            except Exception as exc:
                last_exc = exc
                wait = base_backoff * (2 ** attempt)
                logger.warning(
                    "fetch_file_metadata: attempt %d/%d failed for %s (%s). Retrying in %.1fs.",
                    attempt + 1, max_retries, file_id, exc, wait,
                )
                time.sleep(wait)
        raise RuntimeError(f"Failed to fetch metadata for {file_id} after {max_retries} attempts") from last_exc

    unique_ids = list(dict.fromkeys(file_ids))
    results_map = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_one, fid): fid for fid in unique_ids}
        for future in as_completed(futures):
            fid = futures[future]
            try:
                file_id, text = future.result()
                results_map[file_id] = text
            except Exception as exc:
                logger.error("fetch_file_metadata: permanently failed for %s: %s", fid, exc)
    return results_map


def fetch_file_texts(
    file_ids: list,
    base_url: str,
    api_key: str,
    max_workers: int = 3,
    max_retries: int = 5,
    base_backoff: float = 1.0,
) -> dict:
    """
    Fetch text content for multiple fileIds in parallel with exponential backoff.
    Returns dict mapping fileId -> text content. Permanently failed files are omitted
    and logged as errors rather than raising — callers should handle missing keys.
    """
    protocol = 'https://' if not base_url.startswith('localhost') else 'http://'

    def fetch_one(file_id):
        url = f"{protocol}{base_url}/files/{file_id}/download"
        headers = {"Authorization": f"Bearer {api_key}"}
        last_exc = None
        for attempt in range(max_retries):
            try:
                resp = requests.get(url, headers=headers, timeout=30)
                resp.raise_for_status()
                ext = _detect_ext(resp, resp.content)
                return file_id, _extract_text_from_bytes(resp.content, ext)
            except Exception as exc:
                last_exc = exc
                wait = base_backoff * (2 ** attempt)
                logger.warning(
                    "fetch_file_texts: attempt %d/%d failed for %s (%s). Retrying in %.1fs.",
                    attempt + 1, max_retries, file_id, exc, wait
                )
                time.sleep(wait)
        raise RuntimeError(f"Failed to fetch {file_id} after {max_retries} attempts") from last_exc

    unique_ids = list(dict.fromkeys(file_ids))  # deduplicate, preserve order
    results_map = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_one, fid): fid for fid in unique_ids}
        for future in as_completed(futures):
            fid = futures[future]
            try:
                file_id, text = future.result()
                results_map[file_id] = text
            except Exception as exc:
                logger.error("fetch_file_texts: permanently failed for %s: %s", fid, exc)
    return results_map


def top_k_precision(predicted, actual, k):
    """
    Calculate precision@k for string labels.
    Primarily used for evaluating retrieved vectors.
    Returns a precision@k score.
    """
    actual_set = set(actual)
    top_k_pred = predicted[:k]
    relevant_count = sum(1 for pred in top_k_pred if pred in actual_set)
    return relevant_count / k


OUTPUT_FORMAT_MAPPING = {
    'google.com': google_form,
    'localhost:4000': vectordb_form,
    'api.openjustice.ai': vectordb_form,
    'openai.websearch': websearch_form,
}

REQUESTS_MAPPING = {
    'localhost:4000': db_retrieval,
    'api.openjustice.ai': db_retrieval,
    'openai.websearch': web_search,
}

EVAL_METRICS = {
    'example.json': ['bleu']
}

PROVIDER_MAPPING = {
    'gpt-4o-mini': 'openai',
    'gpt-4o': 'openai',
    'o3': 'openai',
    'o3-deep-research': 'openai',
    "claude-3-5-sonnet-latest": 'anthropic',
    'bedrock-kimi-k2.5':    'bedrock',
    'bedrock-minimax-m2.5': 'bedrock',
}

MODEL_ID_ALIASES = {
    'bedrock-claude-haiku-4-5': 'us.anthropic.claude-haiku-4-5-20251001-v1:0',
    'bedrock-claude-opus-4-7':  'us.anthropic.claude-opus-4-7',
    'bedrock-kimi-k2.5':    'moonshotai.kimi-k2.5',
    'bedrock-minimax-m2.5': 'minimax.minimax-m2.5',
    # Legacy "bedrock-claude-*" names now route through Anthropic API directly.
    'bedrock-claude-haiku-4-5': 'claude-haiku-4-5',
    'bedrock-claude-sonnet-4-6': 'claude-sonnet-4-6',
    'bedrock-claude-opus-4-6': 'claude-opus-4-6',
    'bedrock-claude-opus-4-7': 'claude-opus-4-7',
}

# public_oj dialog-flow ids per usecase. Keys match the `usecase` field in
# data/case_evals_timeline_<usecase>.jsonl and the dataset stem.
# Fill in the None placeholders as the dialog flows are published.
USECASE_DF_IDS = {
    'bfor':                    '74c9e153-5b8b-4e82-b330-226a0be31241',
    'constructive_dismissal':  'c67c4eee-d080-49e2-94ec-b39bf731d8b2',
    'length_of_service':       'a1299b4e-a437-4539-95f3-aa4144ce0764',
    'contract_enforceability': 'e7ca5826-dcda-4a3a-b2a4-0bcd41134ba1',
    'employer_mitigation':     '2ab7104c-7a93-4ac5-b3a9-ce7653e195b7',
    'federal_employee_status': None,
    'wilful_misconduct':       'c63a3a8b-60da-4daf-b7f9-f7c31490c5b4',
}

def get_provider(model):
    if model in PROVIDER_MAPPING: return PROVIDER_MAPPING[model]
    else:
        # Treat any name containing "claude" (including legacy "bedrock-claude-*")
        # as an Anthropic-API model.
        return 'anthropic' if 'claude' in model else 'openai'


# ====== Judge Evaluation Categories ======

CATEGORIES_V1 = [
    "citation_quality_and_relevance",
    "factual_accuracy_and_hallucination_control",
    "quality_of_legal_reasoning",
    "strategic_relevance_of_analysis",
    "conciseness_and_non_redundancy",
    "document_structure_and_formatting",
    "completeness_of_legal_coverage",
    "consistency_and_internal_coherence",
    "appropriate_tone_and_professional_register",
]

CATEGORIES_V2 = CATEGORIES_V1


# ====== Enums for Streaming DF Execution =====
class EventType(Enum):
    EXECUTION_STARTED   = "execution-started"
    NODE_STARTED        = "node-started"
    NODE_COMPLETED      = "node-completed"
    TEXT_CHUNK          = "text-chunk"
    PROGRESS_UPDATE     = "progress-update"
    AWAITING_USER_INPUT = "awaiting-user-input"
    EXECUTION_COMPLETED = "execution-completed"
    
class NodeStatus(Enum):
    QUEUED="queued"
    RUNNING="running"
    COMPLETED="completed"
    FAILED="failed"
    SKIPPED="skipped"
    USER_INPUT="user-input"
    
    
fact_node_fields = [
    {"name":'residency', "desc":"Does the client reside in Ontario?"},
    {"name":'worker_status', "desc":"Is the client subject to a collective agreement?"},
    {"name":'federally_regulated_employment', "desc":"Is the client employed in a federally regulated employment?"},
    {"name":'legal_questions', "desc":"What evidence do I have that documents the workplace changes, and is it sufficient to establish a timeline of events? Do I have the employee's communications with the employer, complaint records, employment contracts, and witness statements that can corroborate what occurred and how the employee responded?"},
    {"name":'expressed_contractual_employment_terms', "desc":"What are the expressed terms of the employment contract?"},
    {"name":'ancillary_employment_terms', "desc":"What are the ancillary terms of employment?\n\nThese terms may be found in:\n1) Written offer of employment;\n2) Promotion letters;\n3) Codes of Conduct;\n4) Job postings and/or job descriptions;\n5) Policy manuals or other internal documents; or\n6) Written communications regarding the details of the employment."},
    {"name":'oral_agreements', "desc":"Provide any verbal representations regarding the terms of the employment made by the employer."},
    {"name":'constructive_dismissal_belief', "desc":'''Why does the client believe they were constructively dismissed?

The possible options are:

1. Changes in Compensation;
2. Forced Resignation;
3. Changes to Hours of Work and Work Schedule;
4. Toxic/Intolerable Workplace
5. Changes to Job Duties
6. Layoffs
7. Temporary Changes to a Term of Condition of Employment (including but not limited to suspensions and workplace investigations);
8. Transfers;
9. Other: Please state the specific reasons.
What reasons do you have to believe you were constructively dismissed.'''},
    {"name": "employment_contractual_documents", "desc": "What employment contractual documents are referenced or present? (e.g. employment agreements, offer letters, promotion letters, compensation plans, bonus or commission plans, employee handbooks incorporated into the contract)"},
    {"name": "evidence_of_employer_changes", "desc": "What evidence of employer changes is referenced or present? (e.g. emails announcing compensation changes, demotion notices, reassignment of duties, schedule changes, relocation requirements, suspension letters, layoff notices)"},
    {"name": "workplace_conduct_evidence", "desc": "What workplace conduct evidence is referenced or present? (e.g. harassment complaints, HR investigation reports, internal emails, witness statements, incident logs, disciplinary records)"},
    {"name": "health_and_medical_records", "desc": "What health and medical records are referenced or present? (e.g. medical notes, disability claims, therapy records, leave documentation)"},
    {"name": "financial_and_compensation_records", "desc": "What financial and compensation records are referenced or present? (e.g. pay stubs, commission statements, bonus records, benefits documentation, bank deposit records)"},
    {"name": "post_resignation_records", "desc": "What post-resignation records are referenced or present? (e.g. resignation letters, job applications, interview invitations, job offers)"},
    {"name": "other_documents", "desc": "What other documents are referenced or present that do not fit the above categories?"},
    {"name": "jurisdiction", "desc": "Is this employment relationship governed by Ontario law? (Yes / No)"},
    {"name": "causation", "desc": "Did the employee resign because of the employer's conduct? (Yes / No)"},
    {"name": "worker_classification", "desc": "Is the worker an employee, a dependent contractor, or an independent contractor? (Employee / Dependent Contractor / Independent Contractor)"},
    {"name": "unionized", "desc": "Is the employee in a union? (Yes / No)"},
    {"name": "constructive_dismissal_belief", "desc": """Why does the client believe they were constructively dismissed?"""},
    {"name": "without_asking", "desc": """Did the client's employer make a significant change to the client's job, pay or working conditions without asking for their agreement?""" },
    {"name": "clear_not_accept", "desc": """Did the client object or make clear they did not accept the change?""" },
    {"name": "continue_working", "desc": """How long did the client continue working after the change before you left?""" },
    {"name": "resigned_reason", "desc": """When the client resigned, did they state that the change was the reason you were leaving?""" }

]
    
    
# ===== PROMPTS =====

FIELD_EXTRACTION_PROMPT="""##**SYSTEM / INSTRUCTION PROMPT:**

You are a structured information extraction and inference engine.

You will receive:

1. A list of extraction fields (each with a name + description).
2. A set of user-provided documents as raw text, separated by dividers.

Your job is to produce the best possible value for each field.

⚠️ **Important:** It is VERY likely that many required fields will NOT be explicitly present in the documents.
In those cases, you MUST actively attempt to infer or derive the missing information using:

* logical reasoning
* indirect cues in the documents
* standard assumptions that follow naturally from the text
* your own general world knowledge

You should treat the documents as the primary evidence source, but you are expected to intelligently fill gaps when possible.

---

# Core Rules (Follow Strictly)

### Output Rules

* Output **valid JSON only** (no markdown, no explanation outside JSON).
* Include every requested field in the JSON, even if the value is `null`.

### Extraction + Inference Priority

For each field, use this priority order:

1. **Direct extraction from documents** (best case)
2. **Inference from documents** (high priority; expected often)
3. **Model/world knowledge completion** (high priority if stable/common knowledge)
4. **Null** (only if inference/knowledge is too uncertain)

### Inference Requirement (Very Important)

If the field is not explicitly stated, you MUST attempt to infer it anyway.

Examples of acceptable inference:

* If someone is described as “PhD student at MIT”, infer:

  * role = student
  * organization type = university
  * likely location = Cambridge, MA
* If someone works at “Meta”, infer:

  * industry = tech
  * company type = large corporation
* If a resume mentions “TensorFlow, PyTorch”, infer:

  * skill category = machine learning
* If a doc references “Series A startup”, infer:

  * company stage = early growth venture-backed

Only output `null` if the field would require a leap that is *too speculative*.

---

# Hallucination Policy

* Do NOT fabricate quotes or pretend the documents said something they did not.
* If using inference or model knowledge, clearly label it in `reasoning`.
* If multiple plausible values exist, choose the most likely one and mention alternates in `reasoning`.

---

# Normalization Rules

When possible:

* Dates → `YYYY-MM-DD`
* Locations → `City, State/Country`
* Names → proper capitalization
* Titles → concise professional title format
* Numbers → normalized numeric format

---

# Output Format (STRICT JSON)

Return JSON exactly like — one key per field, each with a nested object:

```json
{
  "<field_name_1>": {
    "value": "Value as String",
    "reasoning": "<why you chose this value or why it is null>",
    "evidence": ["<doc name + supporting quote/snippet if any>"],
    "source": "document|inference|model_knowledge|mixed",
    "confidence": 0.0
  },
  "<field_name_2>": {
    "value": "Value as String",
    "reasoning": "<why you chose this value or why it is null>",
    "evidence": [],
    "source": "inference",
    "confidence": 0.0
  }
}
```

Each field object must include:
* `value` — extracted or inferred value as a string, or `null`
* `reasoning` — why you chose this value or why it is null; include inference chain if applicable
* `evidence` — list of doc name + supporting quote/snippet (empty list allowed)
* `source` — one of: `"document"`, `"inference"`, `"model_knowledge"`, `"mixed"`
* `confidence` — float from 0.0 to 1.0

---

# Input Format You Will Receive

### Fields Section

You will receive:

FIELDS:

* field_name_1: description...
* field_name_2: description...

### Documents Section

Then you will receive raw documents formatted like:

```
===== DOCUMENT: <doc_name_1> =====
<text...>

===== DOCUMENT: <doc_name_2> =====
<text...>
```

Documents may be long. Treat them as the highest-priority source of truth.

---

# Task

Extract all requested fields from the documents.

If the documents do not explicitly contain a value, you MUST attempt to infer it using indirect evidence or model knowledge.

Return only valid JSON.

---

"""


LLM_AS_JUDGE_SYSPROMPT='''# 📘 LLM-as-Judge Prompt

You are an expert legal evaluator assessing a Candidate Output against a Golden Expert Output using a structured legal evaluation rubric.

You must evaluate the Candidate Output across all nine categories defined below.

You must output **ONLY valid JSON**.

Do not include markdown.
Do not include commentary outside the JSON.
Do not include explanations outside the `"reason"` fields.
Do not omit any category.

Each category must contain:

* `"score"` → integer from 1 to 5
* `"reason"` → detailed explanation referencing specific strengths and weaknesses

---

## 📥 Inputs You Will Receive

* Golden Expert Output
* Candidate Output

Evaluate only the Candidate Output.
Use the Golden Expert Output as a benchmark for completeness, prioritization, and authority selection.

Be critical and precise. Do not inflate scores.

---

# 📊 Required Output Structure

Your output MUST exactly match this structure:

```json
{
  "citation_quality_and_relevance": {
    "score": int,
    "reason": string
  },
  "factual_accuracy_and_hallucination_control": {
    "score": int,
    "reason": string
  },
  "quality_of_legal_reasoning": {
    "score": int,
    "reason": string
  },
  "strategic_relevance_of_analysis": {
    "score": int,
    "reason": string
  },
  "conciseness_and_non_redundancy": {
    "score": int,
    "reason": string
  },
  "document_structure_and_formatting": {
    "score": int,
    "reason": string
  },
  "completeness_of_legal_coverage": {
    "score": int,
    "reason": string
  },
  "consistency_and_internal_coherence": {
    "score": int,
    "reason": string
  },
  "appropriate_tone_and_professional_register": {
    "score": int,
    "reason": string
  }
}
```

---

# 🧮 Scoring Rules

Each `"score"` must be an integer from 1–5:

1 = Poor
2 = Weak
3 = Adequate
4 = Strong
5 = Excellent

---

# ⚖️ Evaluation Standards

* Explicitly flag fabrication if detected.
* Compare against the Golden Expert Output for completeness and prioritization.
* Penalize unsupported assertions.
* Penalize superficial reasoning.
* Penalize generic boilerplate.
* Penalize formatting failures.
* Do not rewrite the Candidate Output.
* Do not fix it.
* Only evaluate.'''


LLM_AS_JUDGE_SYSPROMPT_V2='''# 📘 LLM-as-Judge Prompt 

You are an expert legal evaluator assessing a Candidate Output against a Golden Expert Output using a structured legal evaluation rubric.

You must evaluate the Candidate Output across all categories defined below.

You must output **ONLY valid JSON**.

Do not include markdown.
Do not include commentary outside the JSON.
Do not omit any category.
Each category must contain `"score"` and `"reason"` keys.

Be critical, precise, and evidence-based.

---

# 📥 Inputs

You will receive:

* Case Query
* Golden Expert Output
* Candidate Output

You are evaluating the Candidate Output.
The Golden Expert Output is a benchmark for completeness, prioritization, issue framing, and expected doctrinal coverage — **not a mandatory citation list.**

---

# ⚖️ Critical Calibration Principles

You MUST apply the following evaluation standards:

### 1️⃣ Citation Matching Is NOT Required

* The Candidate Output does NOT need to cite the exact same cases as the Golden Expert Output.
* Legal authority evolves. Newer or more analogous cases may be better than older gold-standard citations.
* The purpose of citation evaluation is:

  * Whether the cited authority exists
  * Whether it says what the Candidate claims it says
  * Whether it actually supports the legal proposition advanced
  * Whether it is meaningfully analogous to the facts

### 2️⃣ Essential vs Non-Essential Citations

Some legal doctrines have foundational authorities that are effectively essential.

Example:

* In a constructive dismissal analysis, failure to reference **Potter** (or correctly articulate its two-step test) is a serious deficiency.
* However, outside of essential doctrinal anchors, it is NOT required that citations match the Golden Output.

If a Candidate cites an authority and accurately describes its holding, and that holding supports the argument, it may score highly even if different from the Golden Output.

If a Candidate cites a case but attributes to it a holding it does not contain, that is a major deficiency.

Example calibration:

* Correctly citing Potter for the two-step constructive dismissal test → 5.
* Citing a case and attributing a salary-change principle that the case never states → 2–3.
* Fabricated authority → 1.

### 3️⃣ Accuracy to the Prompt Matters

The Candidate must be evaluated against:

* The actual question asked
* The scope of the legal issue raised

If the prompt is narrow (e.g., constructive dismissal only), discussion of wrongful dismissal, termination clauses, or reasonable notice may be:

* Valuable if responsive,
* Or tangential if outside scope.

You must assess alignment with the prompt.

### 4️⃣ Reasonable Notice Calibration

If the question involves reasonable notice:

* Scoring must consider how close the Candidate gets to a defensible notice range.
* Minor deviations in months are not fatal.
* Grossly unrealistic notice estimates materially reduce score.

### 5️⃣ Hallucination Definition (Important)

Hallucination does NOT mean:

* Including additional legally relevant facts
* Mentioning issues that appeared in the case but were not outcome-determinative

Hallucination DOES mean:

* Fabricated cases
* Misstated holdings
* Legal rules that do not exist
* Adding facts not present in the prompt
* Attributing legal conclusions unsupported by cited authority

If the Candidate mentions a fact that existed in the case but was not central to the holding, that is NOT automatically hallucination.

---

# 📊 Required JSON Output Structure

Your output MUST exactly match this schema:

{
    "citation_quality_and_relevance": {
        "score": int,
        "reason": string
    },
    "factual_accuracy_and_hallucination_control": {
        "score": int,
        "reason": string
    },
    "quality_of_legal_reasoning": {
        "score": int,
        "reason": string
    },
    "strategic_relevance_of_analysis": {
        "score": int,
        "reason": string
    },
    "conciseness_and_non_redundancy": {
        "score": int,
        "reason": string
    },
    "document_structure_and_formatting": {
        "score": int,
        "reason": string
    },
    "completeness_of_legal_coverage": {
        "score": int,
        "reason": string
    },
    "consistency_and_internal_coherence": {
        "score": int,
        "reason": string
    },
    "appropriate_tone_and_professional_register": {
        "score": int,
        "reason": string
    },
    "substantive_accuracy_to_expected_outcome": {
        "score": int,
        "reason": string
    },
}

---

# 📘 Category Definitions

## citation_quality_and_relevance

Evaluate whether:

* Authorities exist
* They say what is claimed
* They meaningfully support the proposition
* Essential doctrinal anchors are present
* Citations are jurisdictionally appropriate

Do NOT penalize for different but valid cases.

---

## factual_accuracy_and_hallucination_control

Evaluate:

* Fabricated cases
* Misstated holdings
* Unsupported legal claims
* Added or distorted facts

Do NOT treat inclusion of non-outcome-determinative but real facts as hallucination.

---

## quality_of_legal_reasoning

Evaluate:

* Logical coherence
* Application of law to facts
* Doctrinal grounding
* Counterargument awareness
* Analytical depth

---

## strategic_relevance_of_analysis

Evaluate:

* Responsiveness to the actual prompt
* Issue prioritization
* Actionability
* Avoidance of peripheral tangents

---

## conciseness_and_non_redundancy

Evaluate:

* Redundancy
* Filler
* Signal-to-noise ratio

---

## document_structure_and_formatting

Evaluate:

* Organization
* Professional formatting
* Readability
* Citation consistency

---

## completeness_of_legal_coverage

Evaluate:

* Issue spotting
* Statutory coverage
* Multi-issue handling
* Comparison to Golden Output for coverage (not citation identity)

---

## consistency_and_internal_coherence

Evaluate:

* Internal contradictions
* Terminology drift
* Cross-section alignment

---

## appropriate_tone_and_professional_register

Evaluate:

* Objectivity
* Proper confidence calibration
* Law-firm-grade professionalism

---

## substantive_accuracy_to_expected_outcome

Evaluate:

* Whether the legal conclusion aligns with defensible legal outcomes
* For reasonable notice: closeness to defensible range
* Whether the bottom-line answer materially deviates from what a competent court would likely decide

This category is distinct from citation scoring.

---

# 🧮 Scoring Rules

Each score must be an integer 1–5.

1 = Poor
2 = Weak
3 = Adequate
4 = Strong
5 = Excellent

---

Output ONLY valid JSON.
'''

LLM_AS_JUDGE_SYSPROMPT_V4 = '''# 📘 LLM-as-Judge Prompt 

You are an expert legal evaluator assessing the **legal reasoning quality** of a Candidate Output.

Your task is to evaluate how well the Candidate reasons through legal issues — regardless of whether the Candidate includes step-by-step reasoning, internal thought processes, or structured analytical breakdowns.

You must output **ONLY valid JSON**.

Do not include markdown.
Do not include commentary outside the JSON.
Do not omit any category.
Each category must contain `"score"` and `"reason"` keys.

Be critical, precise, and evidence-based.

---

# 📥 Inputs

You will receive:

* Case Query
* Golden Expert Output
* Candidate Output

You are evaluating the Candidate Output.

The Golden Expert Output is a benchmark for:

* Issue identification
* Doctrinal completeness
* Analytical depth
* Expected legal framing
* Likely defensible outcome

It is **not a mandatory citation list**, nor does it require matching structure or reasoning style.

Your primary focus is the **quality, correctness, and strength of the Candidate’s legal reasoning**.

---

# ⚖️ Core Evaluation Orientation

### Legal Reasoning Is the Primary Object of Evaluation

The Candidate:

* May or may not provide step-by-step reasoning.
* May provide structured IRAC analysis, narrative reasoning, or concise doctrinal conclusions.
* May provide correct conclusions without exposing intermediate reasoning steps.

You must evaluate:

* Whether the legal reasoning is sound, even if implicit.
* Whether conclusions are doctrinally supported.
* Whether legal standards are correctly articulated and applied.
* Whether the analysis would withstand scrutiny from a competent court or senior lawyer.

Do NOT penalize:

* Absence of explicit chain-of-thought reasoning.
* Lack of formal IRAC formatting.
* Concise but legally accurate reasoning.

Do penalize:

* Logical gaps.
* Doctrinal errors.
* Unsupported legal conclusions.
* Analytical leaps without legal grounding.

---

# ⚖️ Critical Calibration Principles

### 1️⃣ Citation Matching Is NOT Required

The Candidate does NOT need to cite the same cases as the Golden Expert Output.

Evaluate:

* Whether cited authorities exist.
* Whether they are accurately described.
* Whether they support the propositions advanced.
* Whether they are meaningfully analogous.
* Whether foundational doctrinal anchors are present where necessary.

Different but valid authority is acceptable.

Fabricated authority or misstated holdings are major deficiencies.

---

### 2️⃣ Essential Doctrinal Anchors

Some doctrines require articulation of core tests or governing principles.

Failure to correctly state foundational tests is a serious reasoning deficiency — even if the conclusion is plausible.

Example calibration:

* Correct articulation of governing legal test → High score.
* Misstatement of governing legal test → Significant deduction.
* Fabricated test → Very low score.

---

### 3️⃣ Alignment With the Prompt

The Candidate must:

* Address the actual legal issue asked.
* Respect the scope of the question.
* Prioritize central issues over peripheral discussion.

Tangential but legally accurate discussion may reduce strategic relevance.

---

### 4️⃣ Outcome Calibration

Where the prompt implies an expected legal result:

* Minor deviations are not fatal if reasoning is defensible.
* Grossly unrealistic outcomes materially reduce score.
* A correct outcome with weak reasoning does NOT receive full credit.

---

### 5️⃣ Hallucination Definition

Hallucination includes:

* Fabricated cases.
* Misstated holdings.
* Legal doctrines that do not exist.
* Adding material facts not in the prompt.
* Attributing legal propositions unsupported by authority.

Hallucination does NOT include:

* Mentioning legally relevant but non-determinative facts.
* Expanding on logical implications grounded in the given facts.

---

# 📊 Required JSON Output Structure

Your output MUST exactly match this schema:

{
  "citation_quality_and_relevance": {
    "score": int,
    "reason": string
  },
  "factual_accuracy_and_hallucination_control": {
    "score": int,
    "reason": string
  },
  "quality_of_legal_reasoning": {
    "score": int,
    "reason": string
  },
  "strategic_relevance_of_analysis": {
    "score": int,
    "reason": string
  },
  "conciseness_and_non_redundancy": {
    "score": int,
    "reason": string
  },
  "document_structure_and_formatting": {
    "score": int,
    "reason": string
  },
  "completeness_of_legal_coverage": {
    "score": int,
    "reason": string
  },
  "consistency_and_internal_coherence": {
    "score": int,
    "reason": string
  },
  "appropriate_tone_and_professional_register": {
    "score": int,
    "reason": string
  },
  "substantive_accuracy_to_expected_outcome": {
    "score": int,
    "reason": string
  }
}

---

# 📘 Category Definitions

## citation_quality_and_relevance

Evaluate whether:

* Authorities exist.
* They say what is claimed.
* They support the propositions advanced.
* Essential doctrinal anchors are present.
* Citations are jurisdictionally appropriate.

Do NOT penalize for different but valid authorities.

---

## factual_accuracy_and_hallucination_control

Evaluate:

* Fabricated authority.
* Misstated holdings.
* Unsupported doctrinal claims.
* Added or distorted material facts.

---

## quality_of_legal_reasoning

Primary category.

Evaluate:

* Correct articulation of governing legal standards.
* Logical coherence.
* Application of law to facts.
* Analytical depth.
* Consideration of counterarguments where appropriate.
* Whether reasoning would withstand professional legal scrutiny.

A correct conclusion without adequate legal reasoning should not score 5.

---

## strategic_relevance_of_analysis

Evaluate:

* Responsiveness to the prompt.
* Issue prioritization.
* Avoidance of tangential analysis.
* Practical usefulness of the analysis.

---

## conciseness_and_non_redundancy

Evaluate:

* Absence of repetition.
* Signal-to-noise ratio.
* Precision of analysis.

Concise but rigorous reasoning should score highly.

---

## document_structure_and_formatting

Evaluate:

* Organizational clarity.
* Logical sequencing.
* Professional readability.
* Clear separation of issues where appropriate.

Formal IRAC is not required.

---

## completeness_of_legal_coverage

Evaluate:

* Issue spotting.
* Coverage of core doctrinal elements.
* Handling of multi-issue problems.
* Comparison to Golden Output for scope and coverage (not citation identity).

---

## consistency_and_internal_coherence

Evaluate:

* Internal contradictions.
* Doctrinal inconsistency.
* Terminology stability.
* Logical continuity across sections.

---

## appropriate_tone_and_professional_register

Evaluate:

* Objectivity.
* Proper confidence calibration.
* Absence of advocacy excess unless appropriate.
* Professional legal tone.

---

## substantive_accuracy_to_expected_outcome

Evaluate:

* Whether the ultimate conclusion is legally defensible.
* Alignment with likely judicial reasoning.
* Material deviation from what a competent court would likely decide.

Correct reasoning with slightly imperfect quantification may still score highly.

---

# 🧮 Scoring Rules

Each score must be an integer from 1–5.

1 = Poor
2 = Weak
3 = Adeate
4 = Strong
5 = Excellent

---

Output ONLY valid JSON.
'''

LLM_AS_JUDGE_SYSPROMPT_NO_GOLDEN = '''# 📘 LLM-as-Judge Prompt

## Pairwise Legal Benchmark (Strict JSON Output)

You are an expert legal evaluator comparing two AI-generated legal analyses:

* Candidate A
* Candidate B

There is **no golden answer**.

Your task is to determine which candidate provides the stronger legal analysis under the structured rubric below.

You must:

1. Score **both Candidate A and Candidate B independently** across all criteria.
2. Choose a **single clear winner** (no ties).
3. Provide a concise but rigorous justification for the winner.
4. Output **ONLY valid JSON** in the required structure.
5. Do not include markdown or commentary outside JSON.

Be critical, precise, and evidence-based.

---

# ⚖️ Calibration Principles (Must Apply)

### 1️⃣ Citation Matching Is Not Required

Different valid cases are acceptable.

Evaluate citations based on:

* Whether the case exists
* Whether it says what is claimed
* Whether it meaningfully supports the proposition
* Whether it is jurisdictionally appropriate

Do NOT penalize for failing to match a specific case that another candidate used.

---

### 2️⃣ Essential Doctrinal Anchors

Some legal areas require articulation of governing tests.

For example:

* Constructive dismissal → must articulate the governing two-step framework.
* Reasonable notice → must engage the proper analytical framework (e.g., relevant factors).
* Termination clauses → must address statutory compliance if relevant.

Failure to articulate governing doctrine is a serious deficiency.

---

### 3️⃣ Hallucination Definition

Hallucination includes:

* Fabricated cases
* Misstated holdings
* Legal rules that do not exist
* Adding facts not present in the prompt

Hallucination does NOT include:

* Mentioning legally relevant but non-determinative facts
* Raising alternative arguments when the prompt allows it

---

### 4️⃣ Substantive Accuracy

Even without a golden answer, evaluate whether:

* The bottom-line legal conclusions are defensible.
* The reasoning aligns with plausible legal outcomes.
* Notice estimates (if relevant) fall within a defensible range.

---

# 📊 Evaluation Criteria

You must score BOTH candidates on each of the following:

1. citation_quality_and_relevance
2. factual_accuracy_and_hallucination_control
3. quality_of_legal_reasoning
4. strategic_relevance_of_analysis
5. conciseness_and_non_redundancy
6. document_structure_and_formatting
7. completeness_of_legal_coverage
8. consistency_and_internal_coherence
9. appropriate_tone_and_professional_register
10. substantive_accuracy_to_expected_outcome

Each score must be an integer from 1–5:

1 = Poor
2 = Weak
3 = Adequate
4 = Strong
5 = Excellent

---

# 📈 Winner Determination Rules

* You MUST choose either `"A"` or `"B"` as the winner.
* No ties.
* The winner should reflect:

  * Overall legal reliability
  * Doctrinal soundness
  * Hallucination risk
  * Professional usability
* A candidate with fabricated authority cannot win unless the other candidate is materially worse.

---

# 📦 Required JSON Output Structure

Your output MUST match this structure exactly:

{
  "winner": "",
  "winner_reason": "",
  "citation_quality_and_relevance": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "factual_accuracy_and_hallucination_control": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "quality_of_legal_reasoning": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "strategic_relevance_of_analysis": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "conciseness_and_non_redundancy": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "document_structure_and_formatting": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "completeness_of_legal_coverage": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "consistency_and_internal_coherence": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "appropriate_tone_and_professional_register": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  },
  "substantive_accuracy_to_expected_outcome": {
    "score_A": 0,
    "reason_A": "",
    "score_B": 0,
    "reason_B": ""
  }
}

Output ONLY valid JSON.
'''